# Project Overview
This project allow the user to comu..!

![alt tag](/mansplain_git.png)

### Just text `hi` to `(708) 887-2966` and our men will explain the rest!

### or vist our website: [mansplainer](http://explainit.men/)

# Running & Testing
In order to run and test this program properly, users must have a command-line interface, Flask, Twilio, Clarifai installed. Once in the proper directory of the program where all the files reside, user can test this program by running:
  $ python mansplainer.py
  
# Built With

### Programming Languages
- Python

### Frameworks and APIs
- Flask
- Twilio
- Clarifai
- Wikipedia
- Bootstrap

# Authors
- Erin Williams
- Henry Shen
- Khalid Alnuaim
- Dandan Lin

# Thanks 🙌

Thank you HackNY for this amazing spring 2017 hackathon.

# One more thing

### Our men won  [Best Hack Using a NYC API](https://devpost.com/software/mansplaintome) 😎

